#!/usr/bin/python3

import base64
import hashlib
import unittest

class Email2DomainError(Exception):
    def __init__(self, msg):
        self.msg = msg

def email2domain(email_address: str) -> str:
    """
    Implements RFC 7929, section 3
    https://tools.ietf.org/html/rfc7929#section-3

    :param email_address:
    :return:
    """
    # The DNS does not allow the use of all characters that are supported
    # in the "local-part" of email addresses as defined in [RFC5322] and
    # [RFC6530].  Therefore, email addresses are mapped into DNS using the
    # following method:
    split = email_address.split("@")
    if len(split) == 2:
        # 1. The "left-hand side" of the email address, called the "local-
        #    part" in both the mail message format definition [RFC5322] and in
        #    the specification for internationalized email [RFC6530]) is
        #    encoded in UTF-8 (or its subset ASCII).  If the local-part is
        #    written in another charset, it MUST be converted to UTF-8.
        local = split[0]
        domain = split[1]
        # 2. The local-part is first canonicalized using the following rules.
        #    If the local-part is unquoted, any comments and/or folding
        #    whitespace (CFWS) around dots (".") is removed.  Any enclosing
        #    double quotes are removed.  Any literal quoting is removed.
        # TODO: ^
        # 3. If the local-part contains any non-ASCII characters, it SHOULD be
        #    normalized using the Unicode Normalization Form C from
        #    [Unicode90].  Recommended normalization rules can be found in
        #    Section 10.1 of [RFC6530].
        # TODO: ^
        # 4. The local-part is hashed using the SHA2-256 [RFC5754] algorithm,
        #    with the hash truncated to 28 octets and represented in its
        #    hexadecimal representation, to become the left-most label in the
        #    prepared domain name.
        hash = hashlib.sha256()
        hash.update(local.encode('utf-8'))
        digest = base64.b16encode(hash.digest()[0:28])\
            .decode("utf-8")\
            .lower()
        # 5. The string "_openpgpkey" becomes the second left-most label in
        #    the prepared domain name.
        # 6. The domain name (the "right-hand side" of the email address,
        #    called the "domain" in [RFC5322]) is appended to the result of
        #    step 2 to complete the prepared domain name.
        return digest + "._openpgpkey." + domain
    else:
        raise Email2DomainError("Email address does not contain @ sign.")


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: {} <email-address>".format(sys.argv[0]))
    else:
        print(email2domain(sys.argv[1]))


class Tests(unittest.TestCase):

    def test_basic(self):
        self.assertEqual(email2domain("hugh@example.com"),
                "c93f1e400f26708f98cb19d936620da35eec8f72e57f9eec01c1afd6._openpgpkey.example.com")
