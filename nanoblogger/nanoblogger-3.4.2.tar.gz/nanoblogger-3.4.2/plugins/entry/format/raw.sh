# NanoBlogger dummy plugin for raw output

# For "raw" processing, don't process the body at all
NB_MetaBody="$NB_MetaBody"

