# NanoBlogger plugin to filter raw page content

MKPAGE_CONTENT="$MKPAGE_CONTENT"

