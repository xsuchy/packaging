"""
Version of vpc
"""
__version__ = '0.7.0'
