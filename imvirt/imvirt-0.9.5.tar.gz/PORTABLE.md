ImVirt Portable
===============

`ImVirt Portable` is a portable version of `ImVirt`
using the `PAR Packager` (`pp`). It is a self contained perl script but lags
the binary helper stuff. This might result in a more inaccurate detection.

Download: https://github.com/DE-IBH/imvirt/downloads
