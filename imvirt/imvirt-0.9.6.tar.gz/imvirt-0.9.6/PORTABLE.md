ImVirt Portable
===============

`ImVirt Portable` is a portable version of `ImVirt`
using the `PAR Packager` (`pp`). It is a self contained perl script but lags
the binary helper stuff. This might result in a more inaccurate detection.

There is a `core` and a `bundle` build of `ImVirt Portable`. The latter
contains all the `PAR Packager` glue and has no additional dependency.

Download: https://github.com/DE-IBH/imvirt/releases/
