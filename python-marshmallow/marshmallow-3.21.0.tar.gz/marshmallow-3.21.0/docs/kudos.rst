*****
Kudos
*****

A hat tip to `Django Rest Framework`_ , `Flask-RESTful`_, and `colander`_ for ideas and API design.

.. _Flask-RESTful: https://flask-restful.readthedocs.io/en/latest/

.. _Django Rest Framework: https://django-rest-framework.org/

.. _colander: https://docs.pylonsproject.org/projects/colander/en/latest/
