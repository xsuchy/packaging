*****
Kudos
*****

A hat tip to `Django Rest Framework`_ , `Flask-RESTful`_, and `colander`_ for ideas and API design.

.. _Flask-RESTful: http://flask-restful.readthedocs.org/en/latest/

.. _Django Rest Framework: http://django-rest-framework.org/

.. _colander: http://docs.pylonsproject.org/projects/colander/en/latest/

