*******
Authors
*******

Lead
====

- Steven Loria `@sloria <https://github.com/sloria>`_

Contributors (chronological)
============================

- Sebastian Vetter `@elbaschid <https://github.com/elbaschid>`_
- Eduard Carreras `@ecarreras <https://github.com/ecarreras>`_
- Joakim Ekberg `@kalasjocke <https://github.com/kalasjocke>`_
- Mark Grey `@DeaconDesperado <https://github.com/DeaconDesperado>`_
- Anders Steinlein `@asteinlein <https://github.com/asteinlein>`_
- Cyril Thomas `@Ketouem <https://github.com/Ketouem>`_
- Austin Macdonald `@asmacdo <https://github.com/asmacdo>`_
- Josh Carp `@jmcarp <https://github.com/jmcarp>`_
- `@amikholap <https://github.com/amikholap>`_
- Sven-Hendrik Haase `@svenstaro <https://github.com/svenstaro>`_
- Eric Wang `@ewang <https://github.com/ewang>`_
- `@philtay <https://github.com/philtay>`_
- `@malexer <https://github.com/malexer>`_
- Andriy Yurchuk `@Ch00k <https://github.com/Ch00k>`_
- Vesa Uimonen `@vesauimonen <https://github.com/vesauimonen>`_
- David Lord `@davidism <https://github.com/davidism>`_
- Daniel Castro `@0xDCA <https://github.com/0xDCA>`_
- Ben Jones `@RealSalmon <https://github.com/RealSalmon>`_
- Patrick Woods `@hakjoon <https://github.com/hakjoon>`_
- Lukas Heiniger `@3rdcycle <https://github.com/3rdcycle>`_
- Ryan Lowe `@ryanlowe0 <https://github.com/ryanlowe0>`_
- Jimmy Jia `@taion <https://github.com/taion>`_
- `@lustdante <https://github.com/lustdante>`_
- Sergey Aganezov, Jr. `@sergey-aganezov-jr <https://github.com/sergey-aganezov-jr>`_
- Kevin Stone `@kevinastone <https://github.com/kevinastone>`_
- Alex Morken `@alexmorken <https://github.com/alexmorken>`_
- Sergey Polzunov `@traut <https://github.com/traut>`_
- Kelvin Hammond `@kelvinhammond <https://github.com/kelvinhammond>`_
- Matt Stobo `@mwstobo <https://github.com/mwstobo>`_
- Max Orhai `@max-orhai <https://github.com/max-orhai>`_
- Praveen `@praveen-p <https://github.com/praveen-p>`_
- Stas Sușcov `@stas <https://github.com/stas>`_
- Florian `@floqqi <https://github.com/floqqi>`_
- Evgeny Sureev `@evgeny-sureev <https://github.com/evgeny-sureev>`_
- Matt Bachmann `@Bachmann1234 <https://github.com/Bachmann1234>`_
- Daniel Imhoff `@dwieeb <https://github.com/dwieeb>`_
- Juan Rossi `@juanrossi <https://github.com/juanrossi>`_
- Andrew Haigh `@nelfin <https://github.com/nelfin>`_
- `@Mise <https://github.com/Mise>`_
- Taylor Edmiston `@tedmiston <https://github.com/tedmiston>`_
- Francisco Demartino `@franciscod <https://github.com/franciscod>`_
- Eric Wang `@ewang <https://github.com/ewang>`_
- Eugene Prikazchikov `@eprikazc <https://github.com/eprikazc>`_
