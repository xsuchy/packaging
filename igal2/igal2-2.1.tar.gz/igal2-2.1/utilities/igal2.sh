#
#
/usr/local/bin/igal2 -n --bigy 510 -y 140 --dest ".igal" --AddSubdir -u -www -pagination 50 -d "$1"
