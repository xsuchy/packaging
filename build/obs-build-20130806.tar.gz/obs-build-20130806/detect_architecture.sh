#!/bin/bash

source common_functions

build_host_arch

echo $BUILD_HOST_ARCH

