

console.log("hello world");
require('./people');
slimer.exit()
