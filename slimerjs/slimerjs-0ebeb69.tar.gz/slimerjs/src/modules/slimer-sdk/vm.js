
// Just a stub for the vm module needed by CoffeeScript

/*
const { Cc, Ci, Cu, Cr } = require('chrome');

function createSandbox(proto) {
    var options = {
        sandboxName: options.name,
        sandboxPrototype: proto,
        wantXHRConstructor: false,
        wantComponents: false,
        wantXrays: true,
    };

  let sandbox = Cu.Sandbox(options.principal, options);

  delete sandbox.Iterator;
  delete sandbox.Components;
  delete sandbox.importFunction;
  delete sandbox.debug;

  return sandbox;
}

*/
