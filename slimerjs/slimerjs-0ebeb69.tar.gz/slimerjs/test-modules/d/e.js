var f = require('./f');

exports.readedFromF = f.var_of_f;