
The original author of files of this project, except files provided
by others project or contributors, is Laurent Jouanneau.

## Contributors

```
$ git shortlog -s -n | cut -c8-
Laurent Jouanneau
Vincent Meurisse
laurentj
Matthew Kastor
Niek van der Maas
Bartvds
Boris Staal
Darren Cook
Jaime Iniesta
fumitoito
Krzysztof Jurewicz
```

See also [contribution graphs on github](https://github.com/laurentj/slimerjs/graphs/contributors).

## Other authors

See the LICENSE file
