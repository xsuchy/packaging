var b = require('./a/module_b')

exports.result = "okay "+ b.result;