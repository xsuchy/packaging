
var id = require('./other');


exports.identity = new id.Identity('Laurent');