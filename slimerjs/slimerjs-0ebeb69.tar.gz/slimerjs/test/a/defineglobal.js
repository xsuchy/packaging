

require.globals.thisIsMyGlobalFunction = function() { return 'result from a global function'}