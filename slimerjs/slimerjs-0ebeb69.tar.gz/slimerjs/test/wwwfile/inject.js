document.getElementById("test").setAttribute('class', 'foo');

var injectedVariable = 'I am here';

pageVariable = "changed it";